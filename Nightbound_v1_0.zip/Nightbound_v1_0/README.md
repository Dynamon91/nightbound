# Nightbound v1.0 — Echo Cave & Save System

An original 3D collectathon platformer prototype for Godot 4.x. Play as a bat adventurer exploring Emberglade.

## New in v1.0
- Added an optional Moonlit Echo Cave pocket with three Memory Orbs.
- Each Memory Orb grants 2 crystals and updates the HUD.
- Added manual save/load using Godot ConfigFile at `user://nightbound_save.cfg`.
- Progress is saved automatically when checkpoints activate, shards/orbs are collected, and the boss is defeated.
- Keeps Star Shard quest, Lira, Gloam Warden, Shadow Dash, checkpoints, Echosense and relics.

## Controls
- **WASD** — move
- **SPACE** — leap / glide while airborne
- **F** — burst charge (combat)
- **E** — Echosense pulse
- **SHIFT** — Shadow Dash (unlocked by defeating the Gloam Warden)
- **P** — save progress
- **O** — load saved progress

## Run
Open `project.godot` in Godot 4.x and run the main scene. Godot is not available in the current build environment, so runtime behavior and compilation have not been verified. This is an expanding prototype, not a finished commercial-scale game.
