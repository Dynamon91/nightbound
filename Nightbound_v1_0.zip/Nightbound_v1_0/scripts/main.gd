extends Node3D

var player: CharacterBody3D
var camera: Camera3D
var hud: Label
var velocity_y := 0.0
var speed := 8.0
var gravity := 26.0
var jump_power := 11.0
var crystals := 0
var health := 3
var checkpoint := Vector3(0,2,0)
var fire_cd := 0.0
var invuln := 0.0
var bob := 0.0
var wing_l: Node3D
var wing_r: Node3D
var body_mesh: Node3D
var secret_nodes: Array[Node3D] = []
var crystal_nodes: Array[Node3D] = []
var checkpoint_markers: Array[Node3D] = []
var reveal_time := 0.0
var message_time := 0.0
var status_message := "Find crystals and listen for hidden secrets!"
var boss_node: Area3D
var boss_health := 3
var boss_cooldown := 0.0
var boss_defeated := false
var npc_node: Area3D
var npc_cooldown := 0.0
var dash_cooldown := 0.0
var dash_time := 0.0
var shadow_dash_unlocked := false
var star_shards := 0
var quest_complete := false
var star_shard_nodes: Array[Area3D] = []
var memory_orbs := 0
var memory_orb_nodes: Array[Area3D] = []

func mat(c:Color):
    var m=StandardMaterial3D.new()
    m.albedo_color=c
    m.roughness=.75
    return m

func mesh_box(parent,pos,size,color):
    var x=MeshInstance3D.new()
    x.position=pos
    x.scale=size
    var b=BoxMesh.new()
    b.size=Vector3.ONE
    x.mesh=b
    x.material_override=mat(color)
    parent.add_child(x)
    return x

func mesh_sphere(parent,pos,scale,color):
    var x=MeshInstance3D.new()
    x.position=pos
    x.scale=scale
    var s=SphereMesh.new()
    s.radius=1.0
    s.height=2.0
    x.mesh=s
    x.material_override=mat(color)
    parent.add_child(x)
    return x

func _ready():
    build_environment()
    build_player()
    build_camera()
    build_hud()
    load_game()

func build_environment():
    mesh_box(self,Vector3(0,-1,0),Vector3(38,1,38),Color("#6eae55"))
    # Moonlit echo cave entrance and interior platforms (a new optional exploration pocket).
    mesh_box(self, Vector3(24, 1.0, -4), Vector3(7, 2.0, 7), Color("#4e607d"))
    mesh_box(self, Vector3(24, 2.1, -7.0), Vector3(4.2, 2.8, 0.7), Color("#27324d"))
    mesh_box(self, Vector3(21.2, 2.1, -4.0), Vector3(0.7, 2.8, 5.8), Color("#27324d"))
    mesh_box(self, Vector3(26.8, 2.1, -4.0), Vector3(0.7, 2.8, 5.8), Color("#27324d"))
    mesh_box(self, Vector3(24, 3.0, -2.0), Vector3(3.5, 0.5, 2.0), Color("#667b9a"))
    for orb_pos in [Vector3(22.2, 2.5, -4.0), Vector3(25.8, 3.6, -2.0), Vector3(24.0, 2.2, -6.0)]:
        create_memory_orb(orb_pos)
    # Main valley
    mesh_box(self,Vector3(-12,1,-9),Vector3(8,2,8),Color("#83c766"))
    mesh_box(self,Vector3(11,3,-14),Vector3(9,2,9),Color("#8dce70"))
    mesh_box(self,Vector3(17,1,9),Vector3(11,2,10),Color("#79b75a"))
    mesh_box(self,Vector3(-17,5,13),Vector3(10,2,10),Color("#96d277"))
    mesh_box(self,Vector3(0,0.1,16),Vector3(15,.08,9),Color("#4ba8dc"))
    # bridges
    mesh_box(self,Vector3(0,.2,7),Vector3(3,.4,10),Color("#9b6b40"))
    mesh_box(self,Vector3(-7,1.5,-9),Vector3(5,.5,2),Color("#a87845"))
    # rocks
    for p in [Vector3(-25,1,-16),Vector3(25,1,-15),Vector3(27,1,20),Vector3(-27,1,22)]:
        mesh_box(self,p,Vector3(2.2,1.5,1.7),Color("#7c8b80"))
    # trees
    for p in [Vector3(-25,1,-22),Vector3(26,1,-22),Vector3(28,1,17),Vector3(-26,1,23)]:
        mesh_box(self,p+Vector3(0,2,0),Vector3(.4,2,.4),Color("#76502e"))
        mesh_sphere(self,p+Vector3(0,4,0),Vector3(2.2,2.2,2.2),Color("#2d8148"))
    # realm gate
    mesh_box(self,Vector3(0,2,-18),Vector3(4,.3,.5),Color("#d7a448"))
    mesh_box(self,Vector3(-2,4,-18),Vector3(.4,4,.5),Color("#d7a448"))
    mesh_box(self,Vector3(2,4,-18),Vector3(.4,4,.5),Color("#d7a448"))
    mesh_sphere(self,Vector3(0,4,-18),Vector3(1.4,1.8,.3),Color("#8c63e8"))
    for p in [Vector3(-8,2,0),Vector3(5,1,-7),Vector3(-12,4,-9),Vector3(11,5,-14),
              Vector3(17,2,9),Vector3(-17,7,13),Vector3(0,1,12),Vector3(24,1,-5),
              Vector3(-20,1,-2),Vector3(5,1,6),Vector3(0,5,-18)]:
        make_crystal(p)
    for p in [Vector3(7,1,1),Vector3(-5,1,-13),Vector3(21,2,2),Vector3(-15,6,13)]:
        make_enemy(p)
    # Checkpoint shrines give the player safer respawn points across the valley.
    create_checkpoint(Vector3(-12, 2.05, -9), "MOSS SHRINE")
    create_checkpoint(Vector3(17, 2.05, 9), "MOON SHRINE")
    # Hidden relic markers are invisible until the bat sends an echolocation pulse.
    create_boss(Vector3(0, 1, -13.5))
    create_npc(Vector3(-6, 1, 4), "LIRA THE WAYFINDER")
    # Three Star Shards form Lira's optional exploration quest.
    for p in [Vector3(-23, 2, 4), Vector3(8, 4, -17), Vector3(22, 2, 16)]:
        create_star_shard(p)
    for p in [Vector3(-21,1,-7), Vector3(7,1,11), Vector3(15,3,-14)]:
        var secret = Node3D.new()
        secret.position = p
        secret.set_meta("secret", true)
        mesh_sphere(secret, Vector3(0,0.6,0), Vector3(.35,.55,.35), Color("#c58cff"))
        mesh_sphere(secret, Vector3(0,1.25,0), Vector3(.14,.14,.14), Color("#fff2a6"))
        secret.visible = false
        add_child(secret)
        secret_nodes.append(secret)


func create_memory_orb(p: Vector3):
    var orb = Area3D.new()
    orb.name = "MemoryOrb"
    orb.position = p
    var collision = CollisionShape3D.new()
    var shape = SphereShape3D.new()
    shape.radius = 0.8
    collision.shape = shape
    orb.add_child(collision)
    mesh_sphere(orb, Vector3.ZERO, Vector3(0.35, 0.35, 0.35), Color("#67eaff"))
    mesh_sphere(orb, Vector3.ZERO, Vector3(0.16, 0.16, 0.16), Color("#ffffff"))
    orb.body_entered.connect(_collect_memory_orb.bind(orb))
    add_child(orb)
    memory_orb_nodes.append(orb)

func _collect_memory_orb(body, orb):
    if body != player or not is_instance_valid(orb):
        return
    memory_orbs += 1
    crystals += 2
    status_message = "MEMORY ORB FOUND! +2 CRYSTALS  (%d/3)" % memory_orbs
    message_time = 2.5
    orb.queue_free()
    save_game()

func save_game():
    var cfg = ConfigFile.new()
    cfg.set_value("progress", "crystals", crystals)
    cfg.set_value("progress", "health", health)
    cfg.set_value("progress", "star_shards", star_shards)
    cfg.set_value("progress", "memory_orbs", memory_orbs)
    cfg.set_value("progress", "quest_complete", quest_complete)
    cfg.set_value("progress", "boss_defeated", boss_defeated)
    cfg.set_value("progress", "shadow_dash_unlocked", shadow_dash_unlocked)
    cfg.set_value("progress", "checkpoint_x", checkpoint.x)
    cfg.set_value("progress", "checkpoint_y", checkpoint.y)
    cfg.set_value("progress", "checkpoint_z", checkpoint.z)
    var err = cfg.save("user://nightbound_save.cfg")
    if err == OK:
        status_message = "GAME SAVED"
        message_time = 1.5

func load_game():
    var cfg = ConfigFile.new()
    if cfg.load("user://nightbound_save.cfg") != OK:
        return
    crystals = int(cfg.get_value("progress", "crystals", crystals))
    health = int(cfg.get_value("progress", "health", health))
    star_shards = int(cfg.get_value("progress", "star_shards", star_shards))
    memory_orbs = int(cfg.get_value("progress", "memory_orbs", memory_orbs))
    quest_complete = bool(cfg.get_value("progress", "quest_complete", quest_complete))
    boss_defeated = bool(cfg.get_value("progress", "boss_defeated", boss_defeated))
    shadow_dash_unlocked = bool(cfg.get_value("progress", "shadow_dash_unlocked", shadow_dash_unlocked))
    checkpoint = Vector3(float(cfg.get_value("progress", "checkpoint_x", checkpoint.x)), float(cfg.get_value("progress", "checkpoint_y", checkpoint.y)), float(cfg.get_value("progress", "checkpoint_z", checkpoint.z)))
    if boss_defeated and is_instance_valid(boss_node):
        boss_node.queue_free()
    status_message = "SAVE LOADED — WELCOME BACK!"
    message_time = 2.5

func create_star_shard(p: Vector3):
    var shard = Area3D.new()
    shard.name = "StarShard"
    shard.position = p
    var collision = CollisionShape3D.new()
    var shape = SphereShape3D.new()
    shape.radius = 0.85
    collision.shape = shape
    shard.add_child(collision)
    var core = mesh_sphere(shard, Vector3.ZERO, Vector3(0.38, 0.55, 0.22), Color("#72f4ff"))
    core.rotation_degrees.z = 45
    mesh_sphere(shard, Vector3(0, 0.1, 0), Vector3(0.13, 0.13, 0.13), Color("#ffffff"))
    shard.body_entered.connect(_collect_star_shard.bind(shard))
    add_child(shard)
    star_shard_nodes.append(shard)

func _collect_star_shard(body, shard):
    if body != player or not is_instance_valid(shard):
        return
    star_shards += 1
    status_message = "STAR SHARD FOUND! %d/3" % star_shards
    message_time = 2.5
    shard.queue_free()
    if star_shards >= 3 and not quest_complete:
        status_message = "ALL STAR SHARDS FOUND! Return to Lira for your reward."
        message_time = 4.0

func create_boss(p: Vector3):
    boss_node = Area3D.new()
    boss_node.name = "GloamWarden"
    boss_node.position = p
    var collision = CollisionShape3D.new()
    var shape = SphereShape3D.new()
    shape.radius = 1.55
    collision.shape = shape
    boss_node.add_child(collision)
    mesh_sphere(boss_node, Vector3(0, 0.85, 0), Vector3(1.2, 1.15, 1.2), Color("#5b2c82"))
    mesh_sphere(boss_node, Vector3(-0.38, 1.15, -0.88), Vector3(0.16, 0.16, 0.12), Color("#ff4b73"))
    mesh_sphere(boss_node, Vector3(0.38, 1.15, -0.88), Vector3(0.16, 0.16, 0.12), Color("#ff4b73"))
    mesh_box(boss_node, Vector3(-0.78, 1.45, 0.0), Vector3(0.9, 0.12, 0.75), Color("#302044"))
    mesh_box(boss_node, Vector3(0.78, 1.45, 0.0), Vector3(0.9, 0.12, 0.75), Color("#302044"))
    boss_node.body_entered.connect(_boss_hit)
    add_child(boss_node)

func create_npc(p: Vector3, npc_name: String):
    npc_node = Area3D.new()
    npc_node.name = "WayfinderLira"
    npc_node.position = p
    var collision = CollisionShape3D.new()
    var shape = SphereShape3D.new()
    shape.radius = 1.8
    collision.shape = shape
    npc_node.add_child(collision)
    mesh_sphere(npc_node, Vector3(0, 0.8, 0), Vector3(0.48, 0.65, 0.42), Color("#4c9ba9"))
    mesh_sphere(npc_node, Vector3(0, 1.55, -0.05), Vector3(0.34, 0.34, 0.34), Color("#d9b5ef"))
    mesh_box(npc_node, Vector3(0, 1.9, -0.08), Vector3(0.12, 0.55, 0.12), Color("#f3d66c"))
    npc_node.set_meta("npc_name", npc_name)
    add_child(npc_node)

func make_crystal(p):
    var a=Area3D.new()
    a.position=p
    var c=CollisionShape3D.new()
    var sh=SphereShape3D.new()
    sh.radius=.7
    c.shape=sh
    a.add_child(c)
    var gem=mesh_sphere(a,Vector3.ZERO,Vector3(.45,.8,.45),Color("#ffd84f"))
    gem.rotation_degrees=Vector3(0,45,0)
    a.body_entered.connect(_collect.bind(a))
    add_child(a)
    gem.set_meta("base_y", gem.position.y)
    crystal_nodes.append(gem)

func create_checkpoint(p: Vector3, shrine_name: String):
    var marker = Area3D.new()
    marker.position = p
    marker.set_meta("shrine_name", shrine_name)
    var collision = CollisionShape3D.new()
    var shape = SphereShape3D.new()
    shape.radius = 1.7
    collision.shape = shape
    marker.add_child(collision)
    mesh_box(marker, Vector3(0, 0.05, 0), Vector3(1.8, 0.12, 1.8), Color("#4b8f9b"))
    mesh_sphere(marker, Vector3(0, 0.38, 0), Vector3(0.28, 0.42, 0.28), Color("#a6f1ff"))
    marker.body_entered.connect(_checkpoint_touch.bind(marker, p))
    add_child(marker)
    checkpoint_markers.append(marker)

func make_enemy(p):
    var e=Area3D.new()
    e.position=p
    e.set_meta("home",p)
    var c=CollisionShape3D.new()
    var sh=SphereShape3D.new()
    sh.radius=1
    c.shape=sh
    e.add_child(c)
    mesh_sphere(e,Vector3(0,.75,0),Vector3(1,1,1),Color("#b85d17"))
    mesh_sphere(e,Vector3(-.32,1.05,-.72),Vector3(.12,.12,.12),Color.WHITE)
    mesh_sphere(e,Vector3(.32,1.05,-.72),Vector3(.12,.12,.12),Color.WHITE)
    e.body_entered.connect(_enemy_hit.bind(e))
    add_child(e)

func build_player():
    player=CharacterBody3D.new()
    player.position=Vector3(0,1,0)
    add_child(player)
    var c=CollisionShape3D.new()
    var cap=CapsuleShape3D.new()
    cap.radius=.62
    cap.height=2
    c.shape=cap
    player.add_child(c)
    body_mesh=mesh_sphere(player,Vector3(0,.05,0),Vector3(.82,.72,1.0),Color("#33234f"))
    mesh_sphere(player,Vector3(0,.95,-.42),Vector3(.58,.58,.58),Color("#46305f"))
    # Large membrane wings: bat's primary traversal ability.
    wing_l=mesh_box(player,Vector3(-1.15,.45,0),Vector3(1.25,.08,1.15),Color("#7b416f"))
    wing_r=mesh_box(player,Vector3(1.15,.45,0),Vector3(1.25,.08,1.15),Color("#7b416f"))
    # ears
    mesh_box(player,Vector3(-.3,1.55,-.42),Vector3(.18,.5,.12),Color("#3b2854"))
    mesh_box(player,Vector3(.3,1.55,-.42),Vector3(.18,.5,.12),Color("#3b2854"))
    mesh_sphere(player,Vector3(-.21,1.02,-.92),Vector3(.09,.09,.09),Color("#f1b2d0"))
    mesh_sphere(player,Vector3(.21,1.02,-.92),Vector3(.09,.09,.09),Color("#f1b2d0"))

func build_camera():
    camera=Camera3D.new()
    camera.current=true
    camera.position=Vector3(0,5,9)
    add_child(camera)

func build_hud():
    hud=Label.new()
    hud.position=Vector2(24,20)
    hud.add_theme_font_size_override("font_size",24)
    add_child(hud)
    update_hud()

func update_hud():
    var boss_status = "WARDEN: DEFEATED" if boss_defeated else "WARDEN: %d HP" % boss_health
    var dash_status = "SHADOW DASH: READY (SHIFT)" if shadow_dash_unlocked else "SHADOW DASH: LOCKED — DEFEAT THE WARDEN"
    hud.text="NIGHTBOUND  •  EMBERGLADE\nCRYSTALS %02d    HEARTS %d    STAR SHARDS %d/3    MEMORY ORBS %d/3\n%s\nWASD Move   SPACE Leap / Glide   F Burst   E Echosense   SHIFT Dash   P Save   O Load" % [crystals,health,star_shards,memory_orbs,boss_status] + "\n" + dash_status
    if message_time > 0.0:
        hud.text += "\n" + status_message

func _physics_process(delta):
    if player==null:return
    if Input.is_action_just_pressed("save_game"):
        save_game()
    if Input.is_action_just_pressed("load_game"):
        load_game()
    bob+=delta
    fire_cd=max(0.0,fire_cd-delta)
    invuln=max(0.0,invuln-delta)
    reveal_time=max(0.0,reveal_time-delta)
    message_time=max(0.0,message_time-delta)
    boss_cooldown=max(0.0, boss_cooldown-delta)
    dash_cooldown=max(0.0, dash_cooldown-delta)
    dash_time=max(0.0, dash_time-delta)
    npc_cooldown=max(0.0, npc_cooldown-delta)
    if reveal_time<=0:
        for secret in secret_nodes:
            if is_instance_valid(secret):
                secret.visible=false
    var input=Input.get_vector("move_left","move_right","move_forward","move_back")
    var dir=Vector3(input.x,0,input.y)
    if dir.length()>0:
        dir=dir.normalized()
        player.velocity.x=dir.x*speed
        player.velocity.z=dir.z*speed
        player.look_at(player.global_position+dir,Vector3.UP)
    else:
        player.velocity.x=move_toward(player.velocity.x,0,speed*7*delta)
        player.velocity.z=move_toward(player.velocity.z,0,speed*7*delta)
    var glide=Input.is_action_pressed("jump") and not player.is_on_floor()
    if player.is_on_floor():
        if Input.is_action_just_pressed("jump"): velocity_y=jump_power
    else:
        velocity_y-=gravity*delta
        if glide: velocity_y=max(velocity_y,-2.0)
        if glide:
            player.velocity.y += sin(bob*9.0)*0.35
    player.velocity.y=velocity_y
    if Input.is_action_just_pressed("charge"):
        player.velocity += -player.transform.basis.z*13
    # Defeating the Warden unlocks a fast, brief shadow dash.
    if Input.is_action_just_pressed("shadow_dash") and shadow_dash_unlocked and dash_cooldown <= 0.0:
        var dash_dir = Vector3(input.x, 0, input.y)
        if dash_dir.length() < 0.1:
            dash_dir = -player.transform.basis.z
        dash_dir = dash_dir.normalized()
        player.velocity.x = dash_dir.x * 23.0
        player.velocity.z = dash_dir.z * 23.0
        dash_time = 0.22
        dash_cooldown = 1.6
        status_message = "SHADOW DASH!"
        message_time = 0.8
        var dash_fx = mesh_sphere(self, player.global_position, Vector3(0.9, 0.9, 0.9), Color("#9e69f5"))
        dash_fx.transparency = 0.35
        var dash_tween = create_tween()
        dash_tween.tween_property(dash_fx, "scale", Vector3(2.2, 2.2, 2.2), 0.2)
        dash_tween.tween_callback(dash_fx.queue_free)
    if dash_time > 0.0:
        player.velocity.y = max(player.velocity.y, -1.0)
    if Input.is_action_just_pressed("breathe") and fire_cd<=0:
        fire_cd=.55
        # Bat sonic pulse: a short-range original combat/reveal ability.
        var pulse=mesh_sphere(self,player.global_position-player.transform.basis.z*1.6+Vector3.UP*.3,
            Vector3(.7,.7,.7),Color("#c58cff"))
        pulse.scale=Vector3(.2,.2,.2)
        reveal_time = 3.0
        status_message = "ECHOSENSE: hidden relics revealed!"
        message_time = 2.5
        for secret in secret_nodes:
            secret.visible = true
        var tween=create_tween()
        tween.tween_property(pulse,"scale",Vector3(2.8,2.8,2.8),.35)
        tween.tween_callback(pulse.queue_free)
    player.move_and_slide()
    if player.global_position.y < -5:
        respawn()
    # wing animation while airborne
    var wing_angle=18.0 if glide else 0.0
    wing_l.rotation.z=deg_to_rad(wing_angle)
    wing_r.rotation.z=deg_to_rad(-wing_angle)
    # Boss idle motion and proximity-based NPC hint.
    if is_instance_valid(boss_node) and not boss_defeated:
        boss_node.rotate_y(delta * 0.55)
    if is_instance_valid(npc_node) and player.global_position.distance_to(npc_node.global_position) < 2.3 and npc_cooldown <= 0.0:
        if star_shards >= 3 and not quest_complete:
            quest_complete = true
            crystals += 8
            save_game()
            status_message = "LIRA'S QUEST COMPLETE! +8 CRYSTALS — THANK YOU, WAYFINDER!"
            message_time = 5.0
        elif quest_complete:
            status_message = "LIRA: The paths are safer with you here, little bat."
            message_time = 3.0
        else:
            status_message = "LIRA: Find the 3 Star Shards hidden across Emberglade! %d/3" % star_shards
            message_time = 3.0
        npc_cooldown = 4.0
    # Collect revealed relics by approaching them.
    for secret in secret_nodes:
        if is_instance_valid(secret) and secret.visible and player.global_position.distance_to(secret.global_position)<1.5:
            crystals += 3
            status_message = "ANCIENT ECHO RELIC FOUND! +3 crystals"
            message_time = 3.0
            secret.queue_free()
    # Memory orbs pulse gently inside the echo cave.
    for orb in memory_orb_nodes:
        if is_instance_valid(orb):
            orb.rotate_y(delta * 1.8)
            orb.position.y += sin(bob * 2.5 + float(orb.get_instance_id() % 5)) * 0.001
    # Gentle idle motion keeps crystals readable as collectibles.
    for shard in star_shard_nodes:
        if is_instance_valid(shard):
            shard.rotate_y(delta * 1.4)
            shard.position.y += sin(bob * 2.2 + float(shard.get_instance_id() % 7)) * 0.001
    for gem in crystal_nodes:
        if is_instance_valid(gem):
            gem.rotate_y(delta * 1.7)
            gem.position.y = float(gem.get_meta("base_y")) + sin(bob * 2.0 + float(gem.get_instance_id() % 10)) * 0.12
    # camera
    var target=player.global_position+Vector3(0,3.5,8.8)
    camera.global_position=camera.global_position.lerp(target,6*delta)
    camera.look_at(player.global_position+Vector3.UP*.7)
    update_hud()

func _checkpoint_touch(body, marker, checkpoint_pos):
    if body != player:
        return
    if checkpoint.distance_to(checkpoint_pos) > 1.0:
        checkpoint = checkpoint_pos + Vector3(0, 1.0, 0)
        save_game()
        status_message = str(marker.get_meta("shrine_name")) + " CHECKPOINT ACTIVATED"
        message_time = 3.0

func _boss_hit(body):
    if body != player or boss_defeated or boss_cooldown > 0.0:
        return
    if player.velocity.length() > 10.0:
        boss_health -= 1
        boss_cooldown = 1.0
        if boss_health <= 0:
            boss_defeated = true
            shadow_dash_unlocked = true
            crystals += 10
            status_message = "WARDEN DEFEATED! +10 crystals — SHADOW DASH UNLOCKED!"
            message_time = 5.0
            if is_instance_valid(boss_node):
                boss_node.queue_free()
            save_game()
        else:
            status_message = "GLOAM WARDEN HIT! %d strikes remain — BURST AGAIN" % boss_health
            message_time = 2.5
            player.velocity += (player.global_position - boss_node.global_position).normalized() * 7.0
    else:
        health -= 1
        boss_cooldown = 1.0
        player.velocity += (player.global_position - boss_node.global_position).normalized() * 10.0
        status_message = "The Warden strikes back! Use F to burst-charge."
        message_time = 2.0
        if health <= 0:
            respawn()

func respawn():
    player.position=checkpoint
    player.velocity=Vector3.ZERO
    velocity_y=0
    health=3

func _collect(body,item):
    if body==player and is_instance_valid(item):
        crystals+=1
        if crystals%5==0: health=min(3,health+1)
        item.queue_free()

func _enemy_hit(body,enemy):
    if body!=player or invuln>0:return
    # Charging through enemies defeats them.
    if player.velocity.length()>10:
        enemy.queue_free()
        crystals+=1
    else:
        health-=1
        invuln=1.0
        player.velocity+=(player.global_position-enemy.global_position).normalized()*12
        if health<=0: respawn()
