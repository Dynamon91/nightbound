# Nightbound 🦇 — v1.4

An original 3D exploration-platformer prototype starring a small bat adventurer. Explore the moonlit valley of Emberglade, collect crystals, reveal hidden relics, face the Gloam Warden, and discover Memory Orbs.

## Features implemented in the prototype source

- Third-person bat character, camera, and HUD
- Collision-backed floor, platforms, bridges, and cave area
- Crystal pickups, health, checkpoints, and local save/load
- Echosense reveals hidden relics temporarily
- Jump and hold-to-glide, burst-charge, and Shadow Dash unlocked by the boss
- Gloam Warden encounter, Lira's Star Shards quest, and Memory Orbs

## Controls

- **WASD** — move
- **Space** — jump; hold while airborne to glide
- **F** — burst-charge
- **E** — Echosense
- **Shift** — Shadow Dash after unlocking it
- **P** — save
- **O** — load

## Run

1. Install Godot 4.x from https://godotengine.org/download/.
2. Extract this archive.
3. Open the `Nightbound_v1_4` folder in Godot Project Manager and run the main scene.

## Verification status

A GitHub Actions workflow (`.github/workflows/godot-check.yml`) has been added to the repository to perform a headless Godot import/parse check on pushes and pull requests. That workflow has not yet been confirmed passing. The ZIP archive structure has been checked, but this prototype has **not been run or built with Godot in the current environment**. Gameplay, script parsing, input mappings, collisions, and save/load still need verification. The companion PNG is concept art, not a screenshot from a running game.

**Source note:** this expanded local archive is not yet byte-for-byte synchronized with the simpler `scripts/main.gd` currently on the GitHub main branch.
