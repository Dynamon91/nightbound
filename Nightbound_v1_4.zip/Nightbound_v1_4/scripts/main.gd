extends Node3D

const SAVE_PATH := "user://nightbound_save.cfg"
var player: CharacterBody3D
var camera: Camera3D
var hud: Label
var status_label: Label
var speed := 8.0
var gravity := 25.0
var jump_power := 10.5
var crystals := 0
var health := 3
var checkpoint := Vector3(0, 1.5, 3)
var pulse_left := 0.0
var message_left := 0.0
var status_message := "Explore Emberglade • E reveals hidden relics"
var collected: Array[String] = []
var crystal_areas: Dictionary = {}
var relic_areas: Array[Area3D] = []
var checkpoint_areas: Array[Area3D] = []
var wing_l: MeshInstance3D
var wing_r: MeshInstance3D
var bob := 0.0
var boss: Area3D
var boss_hp := 3
var boss_defeated := false
var dash_unlocked := false
var dash_cooldown := 0.0
var dash_timer := 0.0
var star_shards := 0
var quest_done := false
var memory_orbs := 0
var lira: Area3D
var npc_cooldown := 0.0

func material(color: Color, roughness := 0.72) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = roughness
	return m

func visual_box(parent: Node3D, pos: Vector3, size: Vector3, color: Color) -> MeshInstance3D:
	var item := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = size
	item.mesh = mesh
	item.position = pos
	item.material_override = material(color)
	parent.add_child(item)
	return item

func visual_sphere(parent: Node3D, pos: Vector3, scale_value: Vector3, color: Color) -> MeshInstance3D:
	var item := MeshInstance3D.new()
	var mesh := SphereMesh.new()
	mesh.radius = 1.0
	mesh.height = 2.0
	item.mesh = mesh
	item.position = pos
	item.scale = scale_value
	item.material_override = material(color, 0.4)
	parent.add_child(item)
	return item

func solid_box(pos: Vector3, size: Vector3, color: Color) -> void:
	var body := StaticBody3D.new()
	body.position = pos
	var collision := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = size
	collision.shape = shape
	body.add_child(collision)
	add_child(body)
	visual_box(body, Vector3.ZERO, size, color)

func _ready() -> void:
	build_world()
	build_player()
	build_camera()
	build_hud()
	load_game()
	update_hud()

func build_world() -> void:
	solid_box(Vector3(0, -0.5, 0), Vector3(42, 1, 42), Color("#426d45"))
	# Raised mossy platforms and bridges all have real collision.
	for item in [
		[Vector3(-12, 0.4, -9), Vector3(8, 1.2, 8), Color("#79a95a")],
		[Vector3(11, 1.2, -14), Vector3(9, 1.2, 9), Color("#8ac46a")],
		[Vector3(17, 0.4, 9), Vector3(10, 1.2, 10), Color("#6f9f53")],
		[Vector3(-17, 3.3, 13), Vector3(10, 1.2, 10), Color("#91c96f")],
		[Vector3(0, -0.05, 15), Vector3(14, 0.12, 8), Color("#3b98c7")],
		[Vector3(0, 0.12, 7), Vector3(3, 0.35, 10), Color("#9b7047")],
		[Vector3(-7, 1.1, -9), Vector3(5, 0.35, 2), Color("#a87845")]
	]:
		solid_box(item[0], item[1], item[2])
	for p in [Vector3(-25,0,-20), Vector3(25,0,-20), Vector3(26,0,20), Vector3(-26,0,22)]:
		visual_box(self, p + Vector3(0, 1, 0), Vector3(2, 2, 1.8), Color("#7c8b80"))
		visual_box(self, p + Vector3(0, 3, 0), Vector3(0.45, 4, 0.45), Color("#76502e"))
		visual_sphere(self, p + Vector3(0, 5, 0), Vector3(2.1, 2.1, 2.1), Color("#2d8148"))
	# Portal frame and glowing core.
	visual_box(self, Vector3(0, 2, -18), Vector3(4, 0.3, 0.5), Color("#d7a448"))
	visual_box(self, Vector3(-2, 4, -18), Vector3(0.4, 4, 0.5), Color("#d7a448"))
	visual_box(self, Vector3(2, 4, -18), Vector3(0.4, 4, 0.5), Color("#d7a448"))
	visual_sphere(self, Vector3(0, 4, -18), Vector3(1.3, 1.7, 0.28), Color("#8c63e8"))
	for i in range(12):
		var p := Vector3(float((i * 7) % 31) - 15, 1.0 + float(i % 3) * 0.5, float((i * 11) % 31) - 15)
		make_crystal(p, "crystal_%02d" % i)
	for p in [Vector3(-21, 1, -7), Vector3(7, 1, 11), Vector3(15, 3, -14)]:
		make_enemy(p)
	create_checkpoint(Vector3(-12, 1.2, -9), "MOSS SHRINE")
	create_checkpoint(Vector3(17, 1.2, 9), "MOON SHRINE")
	create_boss(Vector3(0, 0, -13.5))
	create_lira(Vector3(-6, 0, 4))
	for p in [Vector3(-23, 1.5, 4), Vector3(8, 3.3, -17), Vector3(22, 1.5, 16)]:
		make_star_shard(p)
	for p in [Vector3(-8, 0.7, 0), Vector3(5, 0.7, -7), Vector3(-15, 4.0, 13)]:
		var relic := Area3D.new()
		relic.position = p
		var shape := SphereShape3D.new()
		shape.radius = 0.8
		var cs := CollisionShape3D.new()
		cs.shape = shape
		relic.add_child(cs)
		visual_sphere(relic, Vector3(0, 0.5, 0), Vector3(0.36, 0.55, 0.36), Color("#c58cff"))
		visual_sphere(relic, Vector3(0, 1.1, 0), Vector3(0.14, 0.14, 0.14), Color("#fff2a6"))
		relic.visible = false
		add_child(relic)
		relic_areas.append(relic)
	# Echo cave entrance and memory orbs: accessible pocket on the eastern edge.
	solid_box(Vector3(24, 0.1, -4), Vector3(8, 0.4, 8), Color("#4e607d"))
	visual_box(self, Vector3(24, 2.1, -7), Vector3(4.2, 2.8, 0.5), Color("#27324d"))
	visual_box(self, Vector3(20.4, 2.1, -4), Vector3(0.5, 2.8, 6), Color("#27324d"))
	visual_box(self, Vector3(27.6, 2.1, -4), Vector3(0.5, 2.8, 6), Color("#27324d"))
	for p in [Vector3(22, 1.2, -4), Vector3(25.5, 1.2, -2), Vector3(24, 1.2, -6)]:
		make_memory_orb(p)

func build_player() -> void:
	player = CharacterBody3D.new()
	player.name = "BatPlayer"
	player.position = checkpoint
	add_child(player)
	var cs := CollisionShape3D.new()
	var capsule := CapsuleShape3D.new()
	capsule.radius = 0.45
	capsule.height = 1.6
	cs.shape = capsule
	player.add_child(cs)
	visual_sphere(player, Vector3(0, 0.15, 0), Vector3(0.55, 0.72, 0.48), Color("#302844"))
	visual_sphere(player, Vector3(0, 0.7, -0.24), Vector3(0.4, 0.4, 0.38), Color("#49385f"))
	wing_l = visual_box(player, Vector3(-0.72, 0.28, 0), Vector3(0.9, 0.07, 0.55), Color("#80517f"))
	wing_r = visual_box(player, Vector3(0.72, 0.28, 0), Vector3(0.9, 0.07, 0.55), Color("#80517f"))
	visual_box(player, Vector3(-0.22, 1.08, -0.3), Vector3(0.14, 0.42, 0.13), Color("#302844"))
	visual_box(player, Vector3(0.22, 1.08, -0.3), Vector3(0.14, 0.42, 0.13), Color("#302844"))
	visual_sphere(player, Vector3(-0.15, 0.75, -0.58), Vector3(0.07, 0.07, 0.07), Color("#ffe5a0"))
	visual_sphere(player, Vector3(0.15, 0.75, -0.58), Vector3(0.07, 0.07, 0.07), Color("#ffe5a0"))

func build_camera() -> void:
	camera = Camera3D.new()
	camera.current = true
	add_child(camera)
	camera.global_position = Vector3(0, 7, 12)
	camera.look_at(Vector3(0, 1, 0))

func build_hud() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)
	hud = Label.new()
	hud.position = Vector2(22, 18)
	hud.add_theme_font_size_override("font_size", 20)
	hud.add_theme_color_override("font_color", Color("#f5f0ff"))
	layer.add_child(hud)
	status_label = Label.new()
	status_label.position = Vector2(22, 115)
	status_label.add_theme_font_size_override("font_size", 17)
	status_label.add_theme_color_override("font_color", Color("#b7f8f3"))
	layer.add_child(status_label)

func make_crystal(pos: Vector3, id: String) -> void:
	var area := Area3D.new()
	area.position = pos
	var cs := CollisionShape3D.new()
	var shape := SphereShape3D.new()
	shape.radius = 0.8
	cs.shape = shape
	area.add_child(cs)
	var gem := visual_sphere(area, Vector3.ZERO, Vector3(0.38, 0.68, 0.38), Color("#ffd84f"))
	gem.rotation_degrees.z = 15
	area.body_entered.connect(_on_crystal_entered.bind(id, area))
	add_child(area)
	crystal_areas[id] = {"area": area, "gem": gem, "base_y": pos.y, "phase": randf() * TAU}

func _on_crystal_entered(body: Node3D, id: String, area: Area3D) -> void:
	if body != player or collected.has(id):
		return
	collected.append(id)
	crystals += 1
	if crystals % 5 == 0:
		health = mini(3, health + 1)
	area.queue_free()
	crystal_areas.erase(id)
	status_message = "CRYSTAL COLLECTED!"
	message_left = 1.5
	save_game()

func make_enemy(pos: Vector3) -> void:
	var enemy := Area3D.new()
	enemy.position = pos
	var cs := CollisionShape3D.new()
	var shape := SphereShape3D.new()
	shape.radius = 0.9
	cs.shape = shape
	enemy.add_child(cs)
	visual_sphere(enemy, Vector3(0, 0.55, 0), Vector3(0.65, 0.7, 0.65), Color("#b85d17"))
	visual_sphere(enemy, Vector3(-0.2, 0.8, -0.48), Vector3(0.08, 0.08, 0.08), Color.WHITE)
	visual_sphere(enemy, Vector3(0.2, 0.8, -0.48), Vector3(0.08, 0.08, 0.08), Color.WHITE)
	enemy.body_entered.connect(_on_enemy_entered.bind(enemy))
	add_child(enemy)

func _on_enemy_entered(body: Node3D, enemy: Area3D) -> void:
	if body != player or not is_instance_valid(enemy):
		return
	if player.velocity.length() > 10.0:
		crystals += 1
		enemy.queue_free()
		status_message = "ENEMY DEFEATED • +1 CRYSTAL"
	else:
		health -= 1
		player.velocity += (player.global_position - enemy.global_position).normalized() * 8.0
		if health <= 0:
			respawn()
		status_message = "Ouch! Burst-charge with F."
	message_left = 2.0

func make_star_shard(pos: Vector3) -> void:
	var shard := Area3D.new()
	shard.position = pos
	var cs := CollisionShape3D.new()
	var shape := SphereShape3D.new()
	shape.radius = 0.75
	cs.shape = shape
	shard.add_child(cs)
	visual_sphere(shard, Vector3.ZERO, Vector3(0.28, 0.42, 0.2), Color("#72f4ff"))
	shard.body_entered.connect(_on_star_shard_entered.bind(shard))
	add_child(shard)

func _on_star_shard_entered(body: Node3D, shard: Area3D) -> void:
	if body != player or not is_instance_valid(shard):
		return
	star_shards += 1
	shard.queue_free()
	status_message = "STAR SHARD FOUND • %d/3" % star_shards
	message_left = 2.0
	if star_shards == 3:
		status_message = "All shards found! Return to Lira."
	save_game()

func create_checkpoint(pos: Vector3, shrine_name: String) -> void:
	var shrine := Area3D.new()
	shrine.position = pos
	shrine.set_meta("shrine_name", shrine_name)
	var cs := CollisionShape3D.new()
	var shape := SphereShape3D.new()
	shape.radius = 1.5
	cs.shape = shape
	shrine.add_child(cs)
	visual_box(shrine, Vector3(0, 0.1, 0), Vector3(1.5, 0.12, 1.5), Color("#4b8f9b"))
	visual_sphere(shrine, Vector3(0, 0.4, 0), Vector3(0.24, 0.4, 0.24), Color("#a6f1ff"))
	shrine.body_entered.connect(_on_checkpoint_entered.bind(shrine, pos))
	add_child(shrine)
	checkpoint_areas.append(shrine)

func _on_checkpoint_entered(body: Node3D, shrine: Area3D, pos: Vector3) -> void:
	if body != player:
		return
	checkpoint = pos + Vector3(0, 1.1, 0)
	status_message = "%s CHECKPOINT ACTIVATED" % shrine.get_meta("shrine_name")
	message_left = 2.0
	save_game()

func create_boss(pos: Vector3) -> void:
	boss = Area3D.new()
	boss.name = "GloamWarden"
	boss.position = pos
	var cs := CollisionShape3D.new()
	var shape := SphereShape3D.new()
	shape.radius = 1.4
	cs.shape = shape
	boss.add_child(cs)
	visual_sphere(boss, Vector3(0, 0.8, 0), Vector3(1.0, 1.1, 1.0), Color("#5b2c82"))
	visual_sphere(boss, Vector3(-0.3, 1.1, -0.75), Vector3(0.13, 0.13, 0.1), Color("#ff4b73"))
	visual_sphere(boss, Vector3(0.3, 1.1, -0.75), Vector3(0.13, 0.13, 0.1), Color("#ff4b73"))
	boss.body_entered.connect(_on_boss_entered)
	add_child(boss)

func _on_boss_entered(body: Node3D) -> void:
	if body != player or boss_defeated or not is_instance_valid(boss):
		return
	if player.velocity.length() > 10.0:
		boss_hp -= 1
		if boss_hp <= 0:
			boss_defeated = true
			dash_unlocked = true
			crystals += 10
			boss.queue_free()
			status_message = "GLOAM WARDEN DEFEATED • SHADOW DASH UNLOCKED!"
			save_game()
		else:
			status_message = "WARDEN HIT! %d HP LEFT — BURST AGAIN" % boss_hp
	else:
		health -= 1
		player.velocity += (player.global_position - boss.global_position).normalized() * 9.0
		status_message = "Use F to burst-charge at the Warden."
		if health <= 0:
			respawn()
	message_left = 3.0

func create_lira(pos: Vector3) -> void:
	lira = Area3D.new()
	lira.position = pos
	var cs := CollisionShape3D.new()
	var shape := SphereShape3D.new()
	shape.radius = 1.6
	cs.shape = shape
	lira.add_child(cs)
	visual_sphere(lira, Vector3(0, 0.65, 0), Vector3(0.4, 0.6, 0.35), Color("#4c9ba9"))
	visual_sphere(lira, Vector3(0, 1.35, 0), Vector3(0.3, 0.3, 0.3), Color("#d9b5ef"))
	lira.body_entered.connect(_on_lira_entered)
	add_child(lira)

func _on_lira_entered(body: Node3D) -> void:
	if body != player or npc_cooldown > 0:
		return
	npc_cooldown = 3.0
	if star_shards >= 3 and not quest_done:
		quest_done = true
		crystals += 8
		status_message = "LIRA'S QUEST COMPLETE • +8 CRYSTALS!"
	else:
		status_message = "LIRA: Find the 3 Star Shards! %d/3" % star_shards
	message_left = 3.0
	save_game()

func make_memory_orb(pos: Vector3) -> void:
	var orb := Area3D.new()
	orb.position = pos
	var cs := CollisionShape3D.new()
	var shape := SphereShape3D.new()
	shape.radius = 0.65
	cs.shape = shape
	orb.add_child(cs)
	visual_sphere(orb, Vector3.ZERO, Vector3(0.3, 0.3, 0.3), Color("#67eaff"))
	visual_sphere(orb, Vector3.ZERO, Vector3(0.13, 0.13, 0.13), Color.WHITE)
	orb.body_entered.connect(_on_memory_orb_entered.bind(orb))
	add_child(orb)

func _on_memory_orb_entered(body: Node3D, orb: Area3D) -> void:
	if body != player or not is_instance_valid(orb):
		return
	memory_orbs += 1
	crystals += 2
	orb.queue_free()
	status_message = "MEMORY ORB FOUND • +2 CRYSTALS (%d/3)" % memory_orbs
	message_left = 2.5
	save_game()

func _physics_process(delta: float) -> void:
	if player == null:
		return
	bob += delta
	pulse_left = maxf(0.0, pulse_left - delta)
	message_left = maxf(0.0, message_left - delta)
	dash_cooldown = maxf(0.0, dash_cooldown - delta)
	dash_timer = maxf(0.0, dash_timer - delta)
	npc_cooldown = maxf(0.0, npc_cooldown - delta)
	var move_input := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	var direction := Vector3(move_input.x, 0, move_input.y)
	if direction.length() > 0.05:
		direction = direction.normalized()
		player.velocity.x = direction.x * speed
		player.velocity.z = direction.z * speed
		player.rotation.y = atan2(-direction.x, -direction.z)
	else:
		player.velocity.x = move_toward(player.velocity.x, 0.0, speed * 7.0 * delta)
		player.velocity.z = move_toward(player.velocity.z, 0.0, speed * 7.0 * delta)
	if not player.is_on_floor():
		player.velocity.y -= gravity * delta
		if Input.is_action_pressed("jump"):
			player.velocity.y = maxf(player.velocity.y, -2.0)
	elif Input.is_action_just_pressed("jump"):
		player.velocity.y = jump_power
	if Input.is_action_just_pressed("burst"):
		player.velocity += -player.global_basis.z * 13.0
	if Input.is_action_just_pressed("echosense"):
		pulse_left = 4.0
		for relic in relic_areas:
			if is_instance_valid(relic):
				relic.visible = true
		status_message = "ECHOSENSE PULSE • ANCIENT RELICS REVEALED"
		message_left = 2.5
	if Input.is_action_just_pressed("shadow_dash") and dash_unlocked and dash_cooldown <= 0:
		var dash_dir := direction if direction.length() > 0.05 else -player.global_basis.z
		player.velocity.x = dash_dir.normalized().x * 22.0
		player.velocity.z = dash_dir.normalized().z * 22.0
		dash_timer = 0.25
		dash_cooldown = 1.5
		status_message = "SHADOW DASH!"
		message_left = 1.0
	if dash_timer > 0:
		player.velocity.y = maxf(player.velocity.y, -1.0)
	player.move_and_slide()
	if player.global_position.y < -5:
		respawn()
	for id in crystal_areas.keys():
		var entry: Dictionary = crystal_areas[id]
		if is_instance_valid(entry["gem"]):
			entry["gem"].rotate_y(delta * 1.5)
			entry["gem"].position.y = sin(bob * 2.0 + float(entry["phase"])) * 0.08
	for relic in relic_areas:
		if is_instance_valid(relic) and relic.visible and player.global_position.distance_to(relic.global_position) < 1.3:
			crystals += 3
			relic_areas.erase(relic)
			relic.queue_free()
			status_message = "ANCIENT ECHO RELIC FOUND • +3 CRYSTALS"
			message_left = 2.0
			save_game()
			break
	if pulse_left <= 0:
		for relic in relic_areas:
			if is_instance_valid(relic):
				relic.visible = false
	if is_instance_valid(boss) and not boss_defeated:
		boss.rotate_y(delta * 0.5)
	for shard in get_tree().get_nodes_in_group("star_shards"):
		if is_instance_valid(shard):
			shard.rotate_y(delta * 1.5)
	for orb in get_tree().get_nodes_in_group("memory_orbs"):
		if is_instance_valid(orb):
			orb.rotate_y(delta * 1.5)
	var cam_target := player.global_position + Vector3(0, 5.5, 9.0)
	camera.global_position = camera.global_position.lerp(cam_target, minf(1.0, delta * 5.0))
	camera.look_at(player.global_position + Vector3(0, 0.7, 0))
	update_hud()

func update_hud() -> void:
	if hud:
		var boss_text := "WARDEN: DEFEATED" if boss_defeated else "WARDEN: %d HP" % boss_hp
		var dash_text := "DASH: READY (SHIFT)" if dash_unlocked else "DASH: LOCKED"
		hud.text = "NIGHTBOUND • EMBERGLADE\nCRYSTALS %02d   HEARTS %d   STAR SHARDS %d/3   MEMORY ORBS %d/3\n%s   |   %s\nWASD Move  •  SPACE Jump/Glide  •  F Burst  •  E Echosense  •  P Save  •  O Load" % [crystals, health, star_shards, memory_orbs, boss_text, dash_text]
	if status_label:
		status_label.text = status_message if message_left > 0 else "Find Lira, defeat the Gloam Warden, and search for secrets."

func save_game() -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("progress", "crystals", crystals)
	cfg.set_value("progress", "health", health)
	cfg.set_value("progress", "collected", collected)
	cfg.set_value("progress", "checkpoint", [checkpoint.x, checkpoint.y, checkpoint.z])
	cfg.set_value("progress", "boss_hp", boss_hp)
	cfg.set_value("progress", "boss_defeated", boss_defeated)
	cfg.set_value("progress", "dash_unlocked", dash_unlocked)
	cfg.set_value("progress", "star_shards", star_shards)
	cfg.set_value("progress", "quest_done", quest_done)
	cfg.set_value("progress", "memory_orbs", memory_orbs)
	cfg.save(SAVE_PATH)

func load_game() -> void:
	var cfg := ConfigFile.new()
	if cfg.load(SAVE_PATH) != OK:
		return
	crystals = int(cfg.get_value("progress", "crystals", 0))
	health = int(cfg.get_value("progress", "health", 3))
	collected = cfg.get_value("progress", "collected", [])
	var cp = cfg.get_value("progress", "checkpoint", [0, 1.5, 3])
	if cp is Array and cp.size() == 3:
		checkpoint = Vector3(float(cp[0]), float(cp[1]), float(cp[2]))
	boss_hp = int(cfg.get_value("progress", "boss_hp", 3))
	boss_defeated = bool(cfg.get_value("progress", "boss_defeated", false))
	dash_unlocked = bool(cfg.get_value("progress", "dash_unlocked", false))
	star_shards = int(cfg.get_value("progress", "star_shards", 0))
	quest_done = bool(cfg.get_value("progress", "quest_done", false))
	memory_orbs = int(cfg.get_value("progress", "memory_orbs", 0))
	for id in collected:
		if crystal_areas.has(id):
			crystal_areas[id]["area"].queue_free()
			crystal_areas.erase(id)
	if boss_defeated and is_instance_valid(boss):
		boss.queue_free()

func respawn() -> void:
	player.global_position = checkpoint
	player.velocity = Vector3.ZERO
	health = 3

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_P:
			save_game()
			status_message = "GAME SAVED"
			message_left = 1.5
		elif event.keycode == KEY_O:
			load_game()
			status_message = "SAVE LOADED"
			message_left = 1.5
