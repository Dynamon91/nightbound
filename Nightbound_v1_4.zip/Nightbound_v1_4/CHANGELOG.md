# Changelog

## v1.4 — Headless validation setup

- Added a GitHub Actions workflow using Godot 4.3 CI container to check required project files and run a headless editor import/parse pass.
- Included the workflow in this downloadable archive for reproducibility.
- Kept runtime status explicit: the workflow has not yet been confirmed passing and local gameplay has not been tested here.

## Known limitations

- The expanded local archive and the simpler GitHub `scripts/main.gd` are not yet byte-for-byte synchronized.
- Gameplay balance, collision edge cases, and save/load still need testing in Godot 4.x.
