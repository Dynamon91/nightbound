# Nightbound — Models Pack 06

## Models
- `nightbound_enemy_stone_sentinel.glb` — armored guardian enemy for ancient ruins.
- `nightbound_enemy_crystal_bat.glb` — cave swarm enemy with crystal core.
- `nightbound_npc_cartographer.glb` — exploration NPC that can reveal map routes.
- `nightbound_npc_owl_scholar.glb` — lore and hint NPC.
- `nightbound_quest_ancient_key.glb` — dungeon key collectible.
- `nightbound_quest_wind_bell.glb` — mystery prop for a sound-based puzzle.

## Status
Separate stylized GLB concept blockouts. They are not rigged or animated and have no collision, dialogue, quest logic, or Godot import verification. No main-game scene has been changed.
