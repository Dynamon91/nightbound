# Nightbound — Character & Creature Pack 04

## Included GLB assets
- `nightbound_hero_bat_v3.glb`: refined protagonist blockout with layered face and scalloped wings.
- `nightbound_enemy_thornling.glb`: forest ambusher enemy concept.
- `nightbound_npc_lantern_keeper.glb`: friendly lantern-bearing NPC concept intended as a quest giver.
- `nightbound_character_creature_pack_preview.png`: portfolio preview of all three.

## Design status
These are concept blockouts intended to establish silhouette, palette and gameplay roles before engine import. The quest giver is a visual NPC concept only; dialogue, quest logic, rigging, animation, collision and Godot validation are not included yet. Models are separate from the main player scene and do not replace it.

## Suggested next design pass
1. Compare silhouettes against the original mockup and refine proportions.
2. Add enemy variants and NPC quest props that fit the same visual language.
3. Decide rig/animation requirements before engine integration.
4. Import to a separate Godot preview scene and test compatibility before any main-scene changes.
