# Nightbound — Creatures, NPCs & Quest Props Pack 05

## Assets
- `nightbound_enemy_gloom_moth.glb` — hovering moth enemy with glowing core.
- `nightbound_enemy_root_crawler.glb` — ground enemy with root limbs and glowing core.
- `nightbound_npc_mushroom_herbalist.glb` — friendly mushroom-cap herbalist concept.
- `nightbound_quest_moonshard_relic.glb` — collectible quest prop.
- `nightbound_pack05_preview.png` — visual contact sheet.

## Possible gameplay roles
- Gloom Moth: aerial patrol or dive enemy.
- Root Crawler: ground ambusher guarding forest paths.
- Mushroom Herbalist: gives a gathering quest for rare herbs.
- Moonshard: collectible returned to the herbalist to complete a quest.

## Status and limits
These are separate stylized concept blockouts. No rig, animation, collision setup, dialogue, quest scripts, or verified Godot import is included. The main scene and existing player remain untouched.
